/*
 $Id: version.h,v 1.7 2002/04/28 04:44:57 schmidt Exp $
*/
char *version ="Version 1.0.2";
