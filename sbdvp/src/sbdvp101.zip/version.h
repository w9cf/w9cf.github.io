/*
 $Id: version.h,v 1.6 1998/03/12 07:09:41 schmidt Exp $
*/
char *version ="Version 1.0.1";
