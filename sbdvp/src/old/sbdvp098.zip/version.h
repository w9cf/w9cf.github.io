/*
 $Id: version.h,v 1.4 1997/12/16 03:40:20 schmidt Exp $
*/
char *version ="Version 0.9.8";
