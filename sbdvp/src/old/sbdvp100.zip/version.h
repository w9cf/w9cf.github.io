/*
 $Id: version.h,v 1.5 1998/01/31 22:32:27 schmidt Exp $
*/
char *version ="Version 1.0.0";
