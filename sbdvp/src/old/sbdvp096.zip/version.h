/*
 $Id: version.h,v 1.2 1997/10/31 03:06:22 schmidt Exp $
*/
char *version ="Version 0.9.6";
