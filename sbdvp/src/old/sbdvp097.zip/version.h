/*
 $Id: version.h,v 1.3 1997/11/27 07:11:16 schmidt Exp $
*/
char *version ="Version 0.9.7";
