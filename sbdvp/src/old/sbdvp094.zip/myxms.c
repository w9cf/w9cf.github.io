/*
$Id: myxms.c,v 1.0.1.1 1997/09/28 22:50:59 schmidt Exp $
 Copyright (C) 1997, Kevin Schmidt

    This program is free software; you can redistribute it and/or modify 
    it under the terms of the GNU General Public License as published by 
    the Free Software Foundation; either version 2 of the License, or 
    (at your option) any later version. 
 
    This program is distributed in the hope that it will be useful, 
    but WITHOUT ANY WARRANTY; without even the implied warranty of 
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
    GNU General Public License for more details. 
 
    You should have received a copy of the GNU General Public License 
    along with this program; if not, write to the Free Software 
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
 
 You can contact me at W9CF callbook address, or w9cf@ptolemy.la.asu.edu
*/
/*
 functions to manipulate extended memory -- this does not require an
 assembler, but uses the register variables. It works with turbo C v.
 2.0, and probably later versions. These calls are documented in the
 xms 3.0 specification
 
 To use these functions, first call xm_init(), this queries himem.sys
 and gets the address of the function xm() that does all the work.
   xm_installed() returns 1 if an xms driver is installed else 0
   xm_version() returns the version number
   xm_avail(&total) returns the kbytes of available extended memory
   xm_alloc(&handle,size) sets a handle to size kbytes of extended memory
   xm_realloc(&handle,size) changes handle to size kbytes of extended memory
   xm_free(&handle) frees extended memory associated with handle
   xm_move(&params) moves data between conventional and extended memory.
     Look at structure XMMOVESTRUCT:
     set handle to zero for conventional memory
     set handle to returned value above for extended memory
     set offsets from beginning of both blocks
     set length to the number of bytes to transfer
*/

#include <dos.h>

typedef struct {
   unsigned long length;
   unsigned int  sourcehandle;
   unsigned long sourceoffset;
   unsigned int  desthandle;
   unsigned long destoffset;
} XMMOVESTRUCT;

int xm_installed(void);
void xm_init(void);
unsigned int xm_version(void);
unsigned int xm_avail(unsigned int *total);
int xm_alloc(int far *handle, unsigned int size);
int xm_realloc(int handle, unsigned int size);
int xm_free(int far *handle);
int xm_move(XMMOVESTRUCT far *params);

void far (*xm)();

int
xm_installed()
{
/*
  This will return 1 if an xms driver is installed
*/
   union REGS reg;
   struct SREGS sreg;
   reg.x.ax = 0x4300;
   int86x(0x2f,&reg,&reg,&sreg);
   if (reg.h.al == 0x80) return 1;
   return 0;
}

void
xm_init()
{
/*
 get address of extended memory function
*/
   union REGS reg;
   struct SREGS sreg;
   reg.x.ax = 0x4310;
   int86x(0x2f,&reg,&reg,&sreg);
   xm = MK_FP(sreg.es,reg.x.bx);
}
unsigned int
xm_avail(unsigned int *total)
{
/*
 return the largest available extended memory block in kilobytes
 the argument returns the total free memory
*/
   unsigned int i;
   _AH = 0x08;
   xm();
   i = _AX;
   *total = _DX;
   return i;
}
int
xm_alloc(int far *handle, unsigned int size)
{
   unsigned int i,j;
   _DX = size;
   _AH = 0x09;
   xm();
   j = _DX;
   i = _AX;
   *handle = j;
   return i;
}

int
xm_realloc(int handle, unsigned int size)
{
   unsigned int i;
   _DX = handle;
   _BX = size;
   _AH = 0x0f;
   xm();
   i = _AX;
   return i;
}

int
xm_free(int far *handle)
{
   unsigned i;
   _DX = *handle;
   _AH = 0x0a;
   xm();
   i = _AX;
   *handle = 0;
   return i;
}

int
xm_move(XMMOVESTRUCT far *params)
{
   unsigned saveds,i;
   saveds = _DS;
   _SI = (unsigned) params;
   _AH = 0x0b;
   xm();
   i = _AX;
   _DS = saveds;
   return i;
}

unsigned int
xm_version()
{
   unsigned int i;
   _AH = 0x00;
   xm();
   i = _AX;
   return i;
}
