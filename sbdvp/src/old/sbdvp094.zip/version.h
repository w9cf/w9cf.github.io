/*
 $Id: version.h,v 1.0.1.1 1997/09/28 22:50:59 schmidt Exp $
*/
char *version ="Version 0.9.4";
