/*
 $Id: version.h,v 1.8 2002/04/29 07:06:50 schmidt Exp $
*/
char *version ="Version 1.0.3";
