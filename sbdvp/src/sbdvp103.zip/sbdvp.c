/*
 $Id: sbdvp.c,v 1.10 2002/04/29 07:07:19 schmidt Exp $
 Copyright (C) 1997, Kevin Schmidt

    This program is free software; you can redistribute it and/or modify 
    it under the terms of the GNU General Public License as published by 
    the Free Software Foundation; either version 2 of the License, or 
    (at your option) any later version. 
 
    This program is distributed in the hope that it will be useful, 
    but WITHOUT ANY WARRANTY; without even the implied warranty of 
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
    GNU General Public License for more details. 
 
    You should have received a copy of the GNU General Public License 
    along with this program; if not, write to the Free Software 
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
 
You can contact me at W9CF callbook address, or w9cf@ptolemy.la.asu.edu
*/
/*
 Routine to interface with TRlog to emulate K1EA's digital voice
 processor using a Soundblaster Pro compatible sound card.
*/
/*
 The TSR stuff is
 mostly copied from the public domain code written by Sherif El-Kassas,
 EB dept Eindhoven, U of Tec, Netherlands, and distributed as
 tc-tsr10.zip.
*/
/*
 Some of the soundblaster code is converted from the public domain
 code from the "Soundblaster Freedom Project"
*/
#include <ctype.h>
#include <string.h>
#include <dos.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <io.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <mem.h>
#include "version.h"
#define TRUE  1
#define FALSE 0
#define LOW(xx) (unsigned char)((xx)&0xff)
#define HIGH(xx) (unsigned char)((xx)>>8)
/*
 Defines for TSR stuff
*/
#define FAR_WORD(seg, ofs)         (* (unsigned far *) MK_FP(seg, ofs) )
#define FAR_CHAR(seg, ofs)         (* (char far *) MK_FP(seg, ofs) )
#define IS_ARENA_HEADER(seg)       ( FAR_CHAR(seg, 0) == 'M' )
#define IS_PSP_ARENA_HEADER(seg)   ( FAR_WORD(seg, 1) == ((seg)+1) )
#define IS_FIRST_ARENA_HEADER(seg) ( IS_ARENA_HEADER( seg )  &&  \
                                     IS_PSP_ARENA_HEADER( seg ) )
#define IS_LAST_ARENA_HEADER(seg)  ( FAR_CHAR(seg, 0) == 'Z')
#define ARENA_SIZE(seg)            ( FAR_WORD(seg, 3) )
#define NEXT_ARENA_HEADER(seg)     ( ARENA_SIZE(seg) + (seg) + 1 )

struct {
   char enable,parallel;
   int addr;
} ptts;

struct {
   char enable,mask;
   int addr;
} recmic; /* this is to flip a line on the parallel port when recording */

struct {
   char enable,mask;
   int addr;
} outaudio; /* this is to flip a line on a parallel port on audio output */

/*
 Definitions for extended memory access
*/
typedef struct {
   unsigned long length;
   unsigned int  sourcehandle;
   unsigned long sourceoffset;
   unsigned int  desthandle;
   unsigned long destoffset;
} XMMOVESTRUCT;

int xm_installed(void);
void xm_init(void);
unsigned int xm_version(void);
unsigned int xm_avail(unsigned int *total);
int xm_alloc(int far *handle, unsigned int size);
int xm_realloc(int handle, unsigned int size);
int xm_free(int far *handle);
int xm_move(XMMOVESTRUCT far *params);

XMMOVESTRUCT xms; /* extended memory transfer structure */
int  handle; /* current handle for extended memory */

/*
 DVPTSR shared memory structure -- thanks N6TR
*/
typedef struct {
   char filename[64];
   int fileopen;
   int command;
   int handle; /* check if these are backwards */
   int repeatdelay; /* check if these are backwards */
   long start;
   long length;
   unsigned char inputgain;
   unsigned char outputgain;
   unsigned char xmitcontrol;
   unsigned char reccontrol;
} DVP_PTR;

DVP_PTR dvp_ptr;

/*
 stuff for sound card
*/
#define WRITESB(xx) {\
   int ii;\
   for (ii=0;ii<32000 &&(inportb(sb.port.write) & 0x80);ii++);\
   outportb(sb.port.write,(xx));\
   }
#define WRITEMIXER(x,y) { outportb(sb.baseio+0x04,(x)); \
			  outportb(sb.baseio+0x05,(y)); }
#define READMIXER(x,y) { outportb(sb.baseio+0x04,(x)); \
			  y = inportb(sb.baseio+0x05); }
#ifndef BLOCK_LENGTH
#define BLOCK_LENGTH 256
#endif
#define BUFFERSIZE 4*BLOCK_LENGTH /*must be less than 64K */
#define MAXFILES 40 /*maximum number of sound files allowed*/
unsigned char buf[BUFFERSIZE]; /* disk buffer and memory for soundbuf */
unsigned char far *soundbuf; /* memory for dma transfer */

struct recfiles {
   char frec[MAXFILES]; /* flag set to true if audio has been recorded */
   char trfiles[MAXFILES][13]; /* sound file names */
   int numfiles; /* current number of files */
   long fsample[MAXFILES]; /* number of bytes for each sound files */
   long fhandle[MAXFILES]; /* extended memory handle for each sound file */
} recfil;
long samples; /* fsample for current file  */

int rate; /* rate in Hertz -- this gets reset to nearest available value */
unsigned char timeconstant; /* time constant related to the rate in Hz*/
char play; /* Play or record */
char noauto; /* normally 0. 1 for SB 1.x to turn off autoinitiate mode*/
int wss,mset;
int vol = 1;

/*
 sound card info
*/
struct {
   int baseio; /* baseio address of sound card */
   char irq; /* interrupt of sound card */
   char dma8; /* 8 bit dma channel for sound card */
   int type; /* model from environment */
   struct {
      int  reset,read,write,poll; 
   } port; /* ports */
} sb;

int pic_mask; /* programmable interrupt controller mask port */

/*
 dma info
*/
struct {
   struct {int  mask,clear,mode,baseaddr,count,page;} port;
   struct {char start,stop;} mask;
   char mode;
} dma;

/*
 interrupt stuff
*/
struct {
   char start,stop,vector;
} irqs;

struct {
   unsigned long addr;
   unsigned int  offset;
   unsigned char page;
   int length;
} bufs; /* sound buffer address and length for dma */

volatile int  done;
volatile char block;
volatile long samplesremaining;
volatile long now;
volatile int sbactive,recording;

int ihand,isave;

extern void    _restorezero(void);
void interrupt (* old_intr_0x60)(void);
void interrupt (* old_intr_sb)(void);
extern int _fmode = O_BINARY;
extern unsigned _heaplen = 128; /* Don't do much memory allocations small heap */
extern unsigned _stklen = 2000; /* Try a small stack */

static struct {
   struct recfiles far *rec;
   unsigned mypsp;
   char c[8];
   unsigned char ins[3];
} dvp_id;

int
initwss()
{
/*
 initialize windows sound system cards
*/
   unsigned i;
   while (inportb(sb.baseio) == 0x80) ;
   outportb(sb.baseio,0x49); /* mode change enable, set i9 address */
/*
 playback off, record off, single dma, full calibration, dma transfers
*/
   outportb(sb.baseio+1,0x1c);
   outportb(sb.baseio,9);
   outportb(sb.baseio,11); /*set i11 address */
   while (inportb(sb.baseio)&0x20); /* wait for calibration */
   outportb(sb.baseio,0x48); /* i8 register */
   if (wss == 8) {
      outportb(sb.baseio+1,0x03); /* 8 bit, mono, 11KHz, */
   } else {
      outportb(sb.baseio+1,0x42); /*16 bit mono, 16KHz */
   }
   while (inportb(sb.baseio) == 0x80);
   outportb(sb.baseio,8);
   outportb(sb.baseio,11); /*set i11 address */
   while (inportb(sb.baseio)&0x20); /* wait for calibration */
   outportb(sb.baseio+2,0x00); /* make sure int is cleared */
   outportb(sb.baseio,0); /* i0 register */
   outportb(sb.baseio+1,0xa7); /* left adc, high gain, mic input */
   outportb(sb.baseio,1); /* i1 register */
   outportb(sb.baseio+1,0x80); /* right adc, min gain, mic input */
   outportb(sb.baseio,2); /* i2 register */
   outportb(sb.baseio+1,0x80); /* mute left aux 1 input */
   outportb(sb.baseio,3); /* i3 register */
   outportb(sb.baseio+1,0x80); /* mute right aux 1 input */
   outportb(sb.baseio,4); /* i4 register */
   outportb(sb.baseio+1,0x80); /* mute left aux 2 input */
   outportb(sb.baseio,5); /* i5 register */
   outportb(sb.baseio+1,0x80); /* mute right aux 2 input */
   outportb(sb.baseio,6); /* i6 register */
   outportb(sb.baseio+1,0x00); /* left dac min attenuation */
   outportb(sb.baseio,7); /* i7 register */
   outportb(sb.baseio+1,0x00); /* right dac min attenuation */
   outportb(sb.baseio,10); /* i10 register */
   outportb(sb.baseio+1,inportb(sb.baseio+1)&0xc0); /* turn off int */
   outportb(sb.baseio,12); /* i12 register */
   outportb(sb.baseio+1,0x8a); /* mode 1 */
   outportb(sb.baseio,13); /*i 13 register */
   outportb(sb.baseio+1,0x00); /* loopback disabled */
   return 1; /* put in error detection later */
}


void
outswitch(int i)
{
   char k;
   if (outaudio.enable) {
      if (i==1) {
         outportb(outaudio.addr,inportb(outaudio.addr)|outaudio.mask);
      } else {
         outportb(outaudio.addr,inportb(outaudio.addr)&~outaudio.mask);
      }
   }
}

void
micswitch(int i)
{
   char k;
   if (recmic.enable) {
      if (i==1) {
         outportb(recmic.addr,inportb(recmic.addr)|recmic.mask);
      } else {
         outportb(recmic.addr,inportb(recmic.addr)&~recmic.mask);
      }
   }
}

void
ptt(int i)
{
   int j;
   outswitch(i);
/* hook for push to talk control i=1 is start transmit, i=0 is stop transmit */
   if (ptts.enable) {
      if (i==1) {
         if (ptts.parallel) {
            j = inportb(ptts.addr+2)|5; /* strobe low, init high */
            outportb(ptts.addr+2,j);
         } else {
            j = inportb(ptts.addr+4)|2; /* rts high */
            outportb(ptts.addr+4,j);
         }
      } else {
         if (ptts.parallel) {
            j = inportb(ptts.addr+2)&(~5); /* strobe high, init low */
            outportb(ptts.addr+2,j);
         } else {
            j = inportb(ptts.addr+4)&(~2);
            outportb(ptts.addr+4,j);
         }
      }
   }
}

void
copyblock(char blocknum)
{
   disable();
   if ((now + BLOCK_LENGTH) <= samples) {
      xms.length = BLOCK_LENGTH;
   } else {
      xms.length = (int)(samples-now);
      memset((void*)(soundbuf+xms.length+blocknum*BLOCK_LENGTH)
        ,mset,BLOCK_LENGTH-xms.length);
   }
   xms.sourcehandle = handle;
   xms.sourceoffset = now;
   xms.desthandle = 0;
   xms.destoffset = (long) (soundbuf+blocknum*BLOCK_LENGTH);
   xm_move(&xms);
   now += BLOCK_LENGTH;
   enable();
}

void
copyfile(int i)
{
   FILE *f;
   unsigned l;
   int fh;
   soundbuf = (unsigned char far *) buf;
   if ((fh = creat(recfil.trfiles[i],S_IREAD|S_IWRITE)) == -1) return;
   _close(fh);
   if ((f = fopen(recfil.trfiles[i],"a+")) != NULL) {
      handle = recfil.fhandle[i];
      samples = recfil.fsample[i];
      now = 0L;
      while (now < samples) {
         xms.sourcehandle = handle;
         xms.desthandle   = 0;
         xms.sourceoffset = now;
         xms.destoffset = (long)(soundbuf);
         xms.length = (samples-now) < BUFFERSIZE ? (samples-now):BUFFERSIZE;
         l = xms.length;
         disable();
         xm_move(&xms);
         enable();
         fwrite(buf,1,l,f);
         now += xms.length;
      }
      fclose(f);
   }
}

void interrupt
intr_sb()
{
/*
 interrupt handler for the sound card
*/
   disable();
   if (done == FALSE) {
      if (play) {
         if (now < samples) {
            if ((now + BLOCK_LENGTH) <= samples) {
               xms.length = BLOCK_LENGTH;
            } else {
               xms.length = (int)(samples-now);
               memset((void*)(soundbuf+xms.length+block*BLOCK_LENGTH)
               ,mset,BLOCK_LENGTH-xms.length);
            }
            xms.sourcehandle = handle;
            xms.sourceoffset = now;
            xms.desthandle = 0;
            xms.destoffset = (long) (soundbuf+block*BLOCK_LENGTH);
            xm_move(&xms);
            now += BLOCK_LENGTH;
         } else {
            memset((void *) (soundbuf+BLOCK_LENGTH*block), mset, BLOCK_LENGTH);
         }
         samplesremaining -= BLOCK_LENGTH;
         block = !block;
         if (samplesremaining < 0) {
            if (wss) {
               outportb(sb.baseio,10);
               outportb(sb.baseio+1,inportb(sb.baseio+1)&0xc0);
               outportb(sb.baseio,9);
               outportb(sb.baseio,0x04);
            } else {
               WRITESB(0xd3);
               WRITESB(0xd0);
               if (!noauto) WRITESB(0xda);
            }
            outportb(dma.port.mask,dma.mask.stop);
            sbactive = FALSE;
            ptt(0);
            done = TRUE;
         }
/*
 if noauto set, reprogram dma and sound card for next half buffer
*/
         if (noauto) {
            dma.mode = sb.dma8+0x48;
            outportb(dma.port.mask,dma.mask.stop);
            outportb(dma.port.clear,0x00);
            outportb(dma.port.mode,dma.mode);
            outportb(dma.port.baseaddr,LOW(bufs.offset+block*BLOCK_LENGTH));
            outportb(dma.port.baseaddr,HIGH(bufs.offset+block*BLOCK_LENGTH));
            outportb(dma.port.count,LOW(bufs.length-1));
            outportb(dma.port.count,HIGH(bufs.length-1));
            outportb(dma.port.page,bufs.page);
            outportb(dma.port.mask,dma.mask.start);
            WRITESB(0x14);
            WRITESB(LOW(BLOCK_LENGTH-1));
            WRITESB(HIGH(BLOCK_LENGTH-1));
         }
      } else {
         if (now < samples) {
            if (noauto) {
               dma.mode = sb.dma8+0x44;
               outportb(dma.port.mask,dma.mask.stop);
               outportb(dma.port.clear,0x00);
               outportb(dma.port.mode,dma.mode);
               outportb(dma.port.baseaddr,LOW(bufs.offset+(!block)*BLOCK_LENGTH));
               outportb(dma.port.baseaddr,HIGH(bufs.offset+(!block)*BLOCK_LENGTH));
               outportb(dma.port.count,LOW(bufs.length-1));
               outportb(dma.port.count,HIGH(bufs.length-1));
               outportb(dma.port.page,bufs.page);
               outportb(dma.port.mask,dma.mask.start);
               WRITESB(0x24);
               WRITESB(LOW(BLOCK_LENGTH-1));
               WRITESB(HIGH(BLOCK_LENGTH-1));
               inportb(sb.port.poll);
            }
            xms.length = ((now+BLOCK_LENGTH)<=samples)?
               (BLOCK_LENGTH):(samples-now);
            xms.sourcehandle = 0;
            xms.sourceoffset = (long) (soundbuf+block*BLOCK_LENGTH);
            xms.desthandle = handle;
            xms.destoffset = now;
            xm_move(&xms);
            now += BLOCK_LENGTH;
            block = !block;
         } else {
            if (wss) {
               outportb(sb.baseio,10);
               outportb(sb.baseio+1,inportb(sb.baseio+1)&0xc0);
               outportb(sb.baseio,9);
               outportb(sb.baseio,0x04);
            } else {
               WRITESB(0xd3);
               WRITESB(0xd0);
               if (!noauto) WRITESB(0xda);
            }
            outportb(dma.port.mask,dma.mask.stop);
            done = TRUE;
            sbactive = FALSE;
            ptt(0);
         }
      }
   }
   enable();
   if (wss) {
      outportb(sb.baseio+2,0x00);
   } else {
      inportb(sb.port.poll);
   }
   if (sb.irq < 8 ) {
      outportb(0x20,0x20); /* acknowledge irq  */
   } else {
      outportb(0xa0,0x20); /* extra acknowledge for high irqs */
      outportb(0x20,0x20); /* acknowledge irq  */
   }
}

void
dofile(int i)
{
   ihand = i;
   samples = recfil.fsample[ihand];
   handle = recfil.fhandle[ihand];
   now = 0;
   samplesremaining = samples;
   samplesremaining -= BLOCK_LENGTH;
   if (play) {
      copyblock(0);
      copyblock(1);
   }
   if (getvect(irqs.vector) != intr_sb) {
      disable();
      outportb(pic_mask,(inportb(pic_mask)|irqs.stop));
      setvect(irqs.vector,intr_sb);
      enable();
   }
   block = 0;
/*
 set up dma
*/
   if (play) {
      if (noauto) {
         dma.mode = sb.dma8+0x48;
      } else {
         dma.mode = sb.dma8+0x58;
      }
   } else {
      if (noauto) {
         dma.mode = sb.dma8+0x44;
      } else {
         dma.mode = sb.dma8+0x54;
      }
   }
   outportb(dma.port.mask,dma.mask.stop);
   outportb(dma.port.clear,0x00);
   outportb(dma.port.mode,dma.mode);
   outportb(dma.port.baseaddr,LOW(bufs.offset));
   outportb(dma.port.baseaddr,HIGH(bufs.offset));
   outportb(dma.port.count,LOW(bufs.length-1));
   outportb(dma.port.count,HIGH(bufs.length-1));
   outportb(dma.port.page,bufs.page);
/*
 set up sound card
*/
   done = FALSE;
   sbactive = TRUE;
   (void) resetsb();
   if (vol && (sb.type == 2 || sb.type == 4)) {
      WRITEMIXER(0x00,0x00); /* reset mixer */
      WRITEMIXER(0x0c,0x00); /* turn on mic and filter */
      WRITEMIXER(0x22,0xee); /* master volume max */
      WRITEMIXER(0x04,0xee); /* voice volume max */
      WRITESB(0xa0); /* turn off stereo input */
   }
   if (wss) {
      if (wss == 8) {
         outportb(sb.baseio,15);
         outportb(sb.baseio+1,LOW(BLOCK_LENGTH-1));
         outportb(sb.baseio,14);
         outportb(sb.baseio+1,HIGH(BLOCK_LENGTH-1));
      } else {
         outportb(sb.baseio,15);
         outportb(sb.baseio+1,LOW(BLOCK_LENGTH/2-1));
         outportb(sb.baseio,14);
         outportb(sb.baseio+1,HIGH(BLOCK_LENGTH/2-1));
      }
      outportb(sb.baseio,10);
      outportb(sb.baseio+1,inportb(sb.baseio+1)|0x02);
   } else {
      WRITESB(0x40); /* Set time constant */
      WRITESB(timeconstant);
      if (!noauto) {
         WRITESB(0x48);
         WRITESB(LOW(BLOCK_LENGTH-1));
         WRITESB(HIGH(BLOCK_LENGTH-1));
      }
   }
   outportb(dma.port.mask,dma.mask.start); /* start dma */
   disable();
   outportb(pic_mask,(inportb(pic_mask)&irqs.start));
   enable();
   if (play) {
      if (wss) {
         outportb(sb.baseio,9);
         outportb(sb.baseio+1,0x05);
      } else {
         WRITESB(0xd1); /* enable speaker */
         if (noauto) {
            WRITESB(0x14);
            WRITESB(LOW(BLOCK_LENGTH-1));
            WRITESB(HIGH(BLOCK_LENGTH-1));
         } else {   
            WRITESB(0x1c);
         }
      }
   } else {
      if (wss) {
         outportb(sb.baseio,9);
         outportb(sb.baseio+1,0x06);
      } else {
         if (noauto) {
            WRITESB(0x24);
            WRITESB(LOW(BLOCK_LENGTH-1));
            WRITESB(HIGH(BLOCK_LENGTH-1));
         } else {   
            WRITESB(0x2c);
         }
      }
   }
}

void
stoprec()
{
   unsigned int i;
   ptt(0);
   micswitch(0);
   disable();
   if (wss) {
      outportb(sb.baseio,10);
      outportb(sb.baseio+1,inportb(sb.baseio+1)&0xc0);
      outportb(sb.baseio,9);
      outportb(sb.baseio,0x04);
   } else {
      WRITESB(0xd3);
      WRITESB(0xd0);
      if (!noauto) WRITESB(0xda);
   }
   outportb(dma.port.mask,dma.mask.stop);
   samples = (now < samples) ? now : samples;
   i = (samples+1023L)/1024L;
   ihand = recfil.fhandle[isave];
   disable();
   xm_realloc(ihand,i);
   enable();
   recfil.fsample[isave] = samples;
   recording = FALSE;
   sbactive = FALSE;
   done = TRUE;
}

void
parse60()
{
/*
 reverse engineered parse of the dvp_ptr commands from TR's output
*/
   int i,j;
   unsigned int jj;
   unsigned int total;
   switch (dvp_ptr.command) {
      case 0x2b: /* is active? */
         if (sbactive) {
            dvp_ptr.command = 1;
         } else {
            dvp_ptr.command = 0;
         }
         break;
      case 0x05: /* kill audio */
         if (recording) stoprec();
         if (sbactive) {
            disable();
            ptt(0);
            if (wss) {
               outportb(sb.baseio,10);
               outportb(sb.baseio+1,inportb(sb.baseio+1)&0xc0);
               outportb(sb.baseio,9);
               outportb(sb.baseio,0x04);
            } else {
               WRITESB(0xd3);
               WRITESB(0xd0);
               if (!noauto) WRITESB(0xda);
            }
            outportb(dma.port.mask,dma.mask.stop);
            done = TRUE;
            sbactive = FALSE;
            enable();
         } else {
            memset(&dvp_ptr,0x00,sizeof(dvp_ptr)); /* escape backs up */
         }
         break;
      case 0x1a: /* transmit file */
         if (recording) stoprec();
         if (sbactive) {
            disable();
            if (wss) {
               outportb(sb.baseio,10);
               outportb(sb.baseio+1,inportb(sb.baseio+1)&0xc0);
               outportb(sb.baseio,9);
               outportb(sb.baseio,0x04);
            } else {
               WRITESB(0xd3);
               WRITESB(0xd0);
               if (!noauto) WRITESB(0xda);
            }
            outportb(dma.port.mask,dma.mask.stop);
            done = TRUE;
            sbactive = FALSE;
            enable();
         }
         for (i=0;i<recfil.numfiles;i++) {
            if(strcmpi(dvp_ptr.filename,recfil.trfiles[i]) == 0) break;
         }
         if ((i >= 0) && (i < recfil.numfiles)) {
            if (dvp_ptr.xmitcontrol == 0x49) ptt(1);
            play = TRUE;
            dofile(i);
         }
         break;
      case 0x04: /* play file no ptt */
         if (dvp_ptr.xmitcontrol == 0x02) {
            if (recording) stoprec();
            if (sbactive) {
               disable();
               if (wss) {
                  outportb(sb.baseio,10);
                  outportb(sb.baseio+1,inportb(sb.baseio+1)&0xc0);
                  outportb(sb.baseio,9);
                  outportb(sb.baseio,0x04);
               } else {
                  WRITESB(0xd3);
                  WRITESB(0xd0);
                  if (!noauto) WRITESB(0xda);
               }
               outportb(dma.port.mask,dma.mask.stop);
               done = TRUE;
               sbactive = FALSE;
               enable();
            }
            ptt(0);
            for (i=0;i<recfil.numfiles;i++) {
               if(strcmpi(dvp_ptr.filename,recfil.trfiles[i]) == 0) break;
            }
            if ((i >= 0) && (i < recfil.numfiles)) {
               play = TRUE;
               dofile(i);
            }
         }
         break;
      case 0x03: /* record file */
         if (recording) stoprec();
         if (sbactive) {
            disable();
            if (wss) {
               outportb(sb.baseio,10);
               outportb(sb.baseio+1,inportb(sb.baseio+1)&0xc0);
               outportb(sb.baseio,9);
               outportb(sb.baseio,0x04);
            } else {
               WRITESB(0xd3);
               WRITESB(0xd0);
               if (!noauto) WRITESB(0xda);
            }
            outportb(dma.port.mask,dma.mask.stop);
            done = TRUE;
            sbactive = FALSE;
            enable();
         }
         ptt(0);
         micswitch(1);
         disable();
         for (i=0;i<recfil.numfiles;i++) {
            if(strcmpi(dvp_ptr.filename,recfil.trfiles[i]) == 0) break;
         }
         if ((i >= 0) && (i < recfil.numfiles)) {
            ihand = recfil.fhandle[i];
            if (!xm_free(&ihand)) break;
         } else {
            i = recfil.numfiles++;
            if (recfil.numfiles > MAXFILES) {
               recfil.numfiles--;
               break;
            }
            for (j=0;j<12;j++) {
               recfil.trfiles[i][j]=dvp_ptr.filename[j];
            }
            recfil.trfiles[i][13] = 0;
         }
         jj = xm_avail(&total);
         if (!xm_alloc(&ihand,jj)) {
            /* error allocating try to keep it from being fatal */
            recfil.trfiles[i][0] = 0; /* don't use this anymore */
            break;
         }
         enable();
         recfil.fhandle[i] = ihand;
         recfil.fsample[i] = 1024L*jj;
         recfil.frec[i] = TRUE;
         play = FALSE;
         isave = i;
         recording = TRUE;
         dofile(i);
         break;
      case 0x1b: /* stop recording file */
         if (recording) stoprec();
         break;
      default:
         break;
    }
    enable();
}

void interrupt
intr_0x60( unsigned bp, unsigned di, unsigned si,
           unsigned ds, unsigned es, unsigned dx,
           unsigned cx, unsigned bx, unsigned ax )
{
   int i;
   enable();
   switch (di) {
   case 0:
      di = _DS;
      si = (unsigned int) &dvp_ptr;
      break;
   case 23:
/*
 my flag to release reset interrupts
 I hope this isn't incompatible with DVPTSR.
*/
       outportb(dma.port.mask,dma.mask.stop);
       (void) resetsb();
       disable();
       setvect(0x60,old_intr_0x60);
       outportb(pic_mask,(inportb(pic_mask)|irqs.stop));
       setvect(irqs.vector,old_intr_sb);
       enable();
       break;
    default:
       parse60();
    }
    ax = 0;
}

int
resetsb()
{
/*
 reset the sound card
*/
   int i,ii;
   if (wss) return initwss();
   outportb(sb.port.reset,1);
/*
 A write to port 0x80 takes about 1 microsecond according to the linux
 documentation (this is one of the dma page registers) and causes
 no harmful side effects.
*/
   outportb(0x80,0);
   outportb(0x80,0);
   outportb(0x80,0);
   outportb(0x80,0);
   outportb(0x80,0);
   outportb(0x80,0);
   outportb(0x80,0);
   outportb(0x80,0);
   (void) inportb(sb.port.reset);
   outportb(sb.port.reset,0);
   for (i=1000;i>0 ;i--) {
      for (ii=0;ii<32000 &&(!(inportb(sb.port.poll) & 0x80));ii++);
      if (inportb(sb.port.read) == 0xaa) break;
   }
   return i;
}

unsigned
program_size(void)
{
  return(* ((unsigned far *) (MK_FP(_psp-1, 3))) );
}

unsigned int
first_mcb(void)
{
/*
 returns the segment address of the first (interesting) memory control
 block. (it skips command.com ??)
*/ 
   register unsigned int seg;
   for ( seg = 0; ! IS_FIRST_ARENA_HEADER( seg ); seg++ ) ;
   seg = NEXT_ARENA_HEADER(seg); /* skip the first block (command.com ?) */
   return(seg);
}

void
free_mem(register unsigned int prog_seg, register unsigned int seg)
{
/*
 Scan memory, starting at seg, and free any blocks that are owned by
 prog_seg
*/
  while ( ! IS_LAST_ARENA_HEADER( seg ) ){
    if (FAR_WORD(seg, 1) == prog_seg)
      freemem(seg+1);
    seg = NEXT_ARENA_HEADER( seg );
  }
}

int
chklabel()
{
   unsigned iseg,off;
   int i,j;
   char far *c;
   unsigned far *ptr;
   char *id1 = "SBDVP000";
   char *id2 = "DVPTSR00";
   union REGS regs;
   iseg = 0x00;
   off = 0x60*4;
   ptr = MK_FP(iseg,off);
   off = ptr[0];
   iseg = ptr[1];
   c = MK_FP(iseg,off);
   c -= 8;
   j = TRUE;
   for (i=0;i<8;i++) if (c[i] != id1[i]) j = FALSE;
   if (j == FALSE) {
      j = TRUE;
      for (i=0;i<8;i++) if (c[i] != id2[i]) j = FALSE;
   }
   return j;
}
void
unloader()
{
   unsigned int seg;
   unsigned int prog_psp_seg;
   unsigned far *ptr;
   unsigned iseg,off;
   int i,j;
   union REGS regs;
   struct recfiles far *rec;

   j = chklabel();
   if (j == FALSE) {
      printf(" DVPTSR00 or SBDVP000 label not found\n");
      printf(" no action taken\n");
      exit(0);
   }
   iseg = 0x00;
   off = 0x60*4;
   ptr = MK_FP(iseg,off);
   prog_psp_seg = FAR_WORD(ptr[1],ptr[0]-10);
   iseg = FAR_WORD(ptr[1],ptr[0]-12);
   off = FAR_WORD(ptr[1],ptr[0]-14);
   rec = MK_FP(iseg,off);
/*
 get address where we store file info and make a local copy
*/
   recfil.numfiles = rec->numfiles;
   for (i=0; i< rec->numfiles;i++) {
      recfil.frec[i] = rec->frec[i];
      recfil.fhandle[i] = rec->fhandle[i];
      recfil.fsample[i] = rec->fsample[i];
      for (j=0;j<13;j++) {
         for (j=0;j<13;j++) recfil.trfiles[i][j] = rec->trfiles[i][j];
      }
   }
   printf("writing new sound files and freeing extended memory\n");
   xm_init();
   for (i=0;i<recfil.numfiles;i++) {
      if (recfil.frec[i]) copyfile(i);
      handle = recfil.fhandle[i];
      if (recfil.fhandle[i] != 0L) xm_free(&handle);
   }
   printf("freeing interrupt 0x60\n");
   regs.x.di = 23;
   regs.x.ax = 1;
   int86(0x60,&regs,&regs);
   printf("unloading program memory\n");
   seg = first_mcb(); /* locate first MCB   */
   if (prog_psp_seg != 0) free_mem(prog_psp_seg, seg);
   if (prog_psp_seg >= 0xa000) free_mem(prog_psp_seg,prog_psp_seg-1);
}

void
rdenv()
{
   char *in,*temp;
   sb.irq = 0; sb.baseio = 0; sb.dma8 = 0; sb.type = 4;
   if (wss) {
      in = getenv("WSS");
   } else {
      in = getenv("BLASTER");
   }
   if (in == NULL) {
      printf("BLASTER or WSS environment variable not set\n");
      printf("set BLASTER = A220 I5 D1 T4\n");
      printf("with 220 replaced with your hex baseio address\n");
      printf("with 5 replaced with your interrupt number\n");
      printf("1 replaced with your dma channel\n");
      printf("4 replaced with your model, model 2 = SBPro, 3 = SB2\n");
      printf("4 = SBPro2, 5 = SBProMCV, 6 = SB16\n");
      exit(0);
   }
   temp = strdup(in);
   in = strtok(temp," \t");
   while(in) {
      switch (toupper(in[0])) {
      case 'A':
         sb.baseio = (int) strtol(in+1,NULL,16);
         break;
      case 'I':
         sb.irq = atoi(in+1);
         break;
      case 'D':
         sb.dma8 = atoi(in+1);
         break;
      case 'T':
         sb.type = atoi(in+1);
         break;
      default:
         break;
      }
   in = strtok(NULL," \t");
   }
   free(temp);
   if (sb.irq == 0 ) {
      printf("Interrupt not set in BLASTER environment variable\n");
      exit(0);
   }
   if (sb.dma8 < 0 || sb.dma8 > 3) {
      printf("DMA channel must be 0, 1, 2, or 3 in BLASTER environment variable\n");
      exit(0);
   }
   if (sb.baseio == 0) {
      printf("Baseio not set in Blaster environment variable\n");
      exit(0);
   }
   if (wss) return;
   if (sb.type == 0) sb.type = 4;
   if (sb.type == 1) {
       printf("Warning: Record quality is poor with SB1 cards\n");
       noauto = 1;
   }
}

main(int argc, char **argv)
{
   FILE *f;
   int i,j,k,fhand;
   int far *ip;
   char *id = "SBDVP000";
   long size;
   unsigned short off;
   unsigned long lin;
   unsigned int total;
   void interrupt (*fake)();
   ptts.enable = FALSE;
   recmic.enable = FALSE;
   outaudio.enable = FALSE;
   rate = 12048;
   wss = 0;
   mset = 127; /* 8 bit center value */
   noauto = 0; /* assume we can use autoinitiate mode */
   printf("program sbdvp %s\n",version);
   if (argc != 1) {
      for (i=1;i<argc;i++) {
         if (argv[i][0] == '-') {
            switch (tolower(argv[i][1])) {
            case 'u':
               printf("unloading program \n");
               unloader();
               exit(0);
            case 'r': /* sampling rate */
               rate = atoi(argv[i]+2);
               if (!rate) rate = 12048;
               break;
            case 'p': /* parallel port ptt */
               ptts.enable = TRUE;
               ptts.parallel = TRUE;
               j = atoi(argv[i]+2);
               if (j < 1 || j > 3) {
                  printf("parallel port must be 1, 2, or 3\n");
                  exit(1);
               }
               ip = MK_FP(0x40,8+2*(j-1));
               ptts.addr = *ip;
               if (ptts.addr == 0 ) {
                  printf("parallel port %d not found \n",j);
                  exit(1);
               }
               break;
            case 's': /* serial port ptt */
               ptts.enable = TRUE;
               ptts.parallel = FALSE;
               j = atoi(argv[i]+2);
               if (j < 1 || j > 4) {
                  printf(" serial port must be 1, 2, 3 or 4\n");
                  exit(1);
               }
               ip = MK_FP(0x40,2*(j-1));
               ptts.addr = *ip;
               if (ptts.addr == 0 ) {
                  printf("serial port %d not found \n",j);
                  exit(1);
               }
               break;
             case 'a': /* force auto initiate mode off */
               noauto = 1;
               break;
             case 'm': /* toggle a parallel port line when recording */
               recmic.enable = TRUE;
               k = atoi(argv[i]+2);
               if (k < 2 || k > 9) {
                  printf("parallel port mic control line must be 2 to 9\n");
                  exit(1);
               }
               recmic.mask = 1<<(k-2);
               if (*(argv[i]+3) != 'p' && *(argv[i]+3) != 'P') {
                  printf("mic control line must be on parallel port\n");
                  exit(1);
               }
               j = atoi(argv[i]+4);
               if (j < 1 || j > 3) {
                  printf("parallel port must be 1, 2, or 3\n");
                  exit(1);
               }
               ip = MK_FP(0x40,8+2*(j-1));
               recmic.addr = *ip;
               if (recmic.addr == 0 ) {
                  printf("parallel port %d not found \n",j);
                  exit(1);
               }
               printf("Pin %d of parallel port %d will be high while recording\n",k,j); 
               break;
             case 'o': /* toggle a parallel port line when outputting audio*/
               outaudio.enable = TRUE;
               k = atoi(argv[i]+2);
               if (k < 2 || k > 9) {
                  printf("outaudio parallel port control line must be 2 to 9\n");
                  exit(1);
               }
               outaudio.mask = 1<<(k-2);
               if (*(argv[i]+3) != 'p' && *(argv[i]+3) != 'P') {
                  printf("audio output control line must be on parallel port\n");
                  exit(1);
               }
               j = atoi(argv[i]+4);
               if (j < 1 || j > 3) {
                  printf("outaudio parallel port must be 1, 2, or 3\n");
                  exit(1);
               }
               ip = MK_FP(0x40,8+2*(j-1));
               outaudio.addr = *ip;
               if (outaudio.addr == 0 ) {
                  printf("parallel port %d not found \n",j);
                  exit(1);
               }
               printf("Pin %d of parallel port %d will be high during soundcard transmit audio output\n",k,j); 
               break;
            case 'w': /* Try Windows Sound System */
               wss = atoi(argv[i]+2);
               if (wss != 8 && wss != 16) {
                  printf("choose 8 or 16 bit samples with WSS\n");
                  exit(1);
               }
               rate = (wss ==16) ? 16000:11000;
               if (wss == 16) mset = 0; /* center value for 16 bit samples */
               break;
            case 'v':
               vol = 0; /* turn off soundblaster mixer stuff */
               break;
            case 'c':
               id = "DVPTSR00"; /* compatibility mode */
               break;
            default:
               printf("usage: %s [-u] [-rnnnnn] [-pn|-sn] [-a] [-mnpn] [-onpn] [-w8 -w16] [-v]\n",argv[0]);
               exit(0);
           }
        }
      }
   }
   if (chklabel()) {
      printf("tsr already loaded\n");
      exit(0);
   }
   _restorezero();
   old_intr_0x60 = getvect(0x60);
/*
 the following is to emulate dvptsr.exe -- it requires that
 DVPTSR00 be the 8 bytes before the beginning of the interrupt
 routine. I fake this by putting DVPTSR00 into a struct which
 then contains a jmp 2_byte_offset machine instruction to the real
 interrupt handler
*/
  fake = (void *) dvp_id.ins;
  off = (unsigned short) intr_0x60 - (unsigned short) fake - 3;
  for (i=0;i<8;i++) dvp_id.c[i] = id[i];
  dvp_id.ins[0] = 0xe9; /* jmp and then offset to real routine */
  dvp_id.ins[1] = LOW(off);
  dvp_id.ins[2] = HIGH(off);
  dvp_id.mypsp = _psp; /* store psp in dvp_id structure */
  dvp_id.rec = (struct recfiles far *) &recfil; /* store file info in dvp_id structure */
/*
sbdvpcfg.dat should look like:
cqf1.dvp
cqf2.dvp
  etc.
if it exists
*/
   rdenv(); /* get soundblaster info from BLASTER environment variable */
   if (noauto) {
      printf("Warning: Autoinitiate DMA has been turned off\n");
      printf("This is necessary on SB1.x cards, but record quality suffers\n");
   }
   printf(" IRQ = %d\n BASEIO = %x\n DMA = %d\n SBTYPE = %d\n"
     ,sb.irq,sb.baseio,sb.dma8,sb.type);
   if (wss) sb.baseio += 4; /* change baseio to Codec base */
   recfil.numfiles = 0;
   if ((f = fopen("sbdvpcfg.dat","r")) != NULL) {
      for (i=0;i<MAXFILES;i++) {
         j = fscanf(f,"%s\n",buf);
         if ((j == EOF) || (j == 0)) break;
         for (j=0;(j<12) || (buf[j] != 0);j++) recfil.trfiles[recfil.numfiles][j]=toupper(buf[j]);
         recfil.trfiles[recfil.numfiles][j] = 0;
         if ((fhand = _open(recfil.trfiles[recfil.numfiles],O_RDONLY)) != -1)  {
            _close(fhand);
            recfil.numfiles++;
         }
      }
      fclose(f);
   }
   if (!xm_installed()) {
      printf("You must have an extended memory driver installed\n");
      printf("Add device=c:\\dos\\himem.sys or equivalent to config.sys\n");
      exit(0);
   }
   xm_init();
   soundbuf = (unsigned char far *) buf;
   for (i=0;i<recfil.numfiles;i++) {
      if ((fhand = _open(recfil.trfiles[i],O_RDONLY)) == -1) {
         recfil.fsample[i] = 0L;
         recfil.fhandle[i] = 0L;
         recfil.frec[i] = FALSE;
      } else {
         recfil.frec[i] = FALSE;
         size = filelength(fhand);
         printf("%s opened %ld bytes\n",recfil.trfiles[i],size);
         samples = size ;
         recfil.fsample[i] = size;
         if (!xm_alloc(&handle, (unsigned int)((size/1024)+1))) {
            printf("error, need %u bytes -- %u free",xm_avail(&total)*1024);
            exit(1);
         } else {
            recfil.fhandle[i] = handle;
            xms.sourcehandle = 0;
            xms.sourceoffset = (long)(soundbuf);
            xms.desthandle = handle;
            xms.destoffset = 0;
            do {
               xms.length = _read(fhand,buf,BUFFERSIZE);
               xm_move(&xms);
               xms.destoffset += xms.length;
               size -= xms.length;
            } while (size > 0);
            _close(fhand);
         }
      }
   }
/*
 compute all the addresses and stuff we need
*/
   sb.port.reset = sb.baseio+0x06;
   sb.port.read = sb.baseio+0x0a;
   sb.port.write = sb.baseio+0x0c;
   sb.port.poll = sb.baseio+0x0e;
   if (sb.irq < 8) {
      irqs.vector = 0x08+sb.irq;
      pic_mask = 0x21;
    } else {
      irqs.vector = 0x68+sb.irq;
      pic_mask = 0xa1;
    }
   irqs.stop = 1 << (sb.irq % 8);
   irqs.start = ~irqs.stop;
   dma.port.mask = 0x0a;
   dma.port.mode = 0x0b;
   dma.port.clear = 0x0c;
   dma.port.baseaddr = 0x00+2*sb.dma8;
   dma.port.count = 0x01+2*sb.dma8;
   switch(sb.dma8) {
      case 0:  dma.port.page = 0x87; break;
      case 1:  dma.port.page = 0x83; break;
      case 2:  dma.port.page = 0x81; break;
      case 3:  dma.port.page = 0x82; break;
   }
   dma.mask.stop  = sb.dma8+0x04;
   dma.mask.start = sb.dma8;
   if (!wss) {
      rate =  (rate > 22900) ? 22900 : rate;
      rate =  (rate < 4000) ? 4000 : rate;
      timeconstant = (unsigned char) (256-((1000000L+rate/2)/rate));
      rate = (int) (1000000L/(256-timeconstant));
   }
   printf("nearest rate is %d Hz\n",rate);
/*
 set up buffer for dma transfer -- Just use the disk buffer,
 but find half that doesn't cross a physical 64K page boundary
*/
   soundbuf = (unsigned char far *) buf;
   lin = (unsigned long)(FP_SEG(soundbuf)*16L)+(unsigned long)(FP_OFF(soundbuf));
   if (((lin % 65536)+2*BLOCK_LENGTH) > 65535) soundbuf+= 2*BLOCK_LENGTH;
   lin = (unsigned long)(FP_SEG(soundbuf)*16L)+(unsigned long)(FP_OFF(soundbuf));
/*
   printf(" buf address %x\n",(int) buf);
   printf(" soundbuf segment offset %x %x\n",FP_SEG(soundbuf),FP_OFF(soundbuf));
*/
   bufs.addr = lin;
   bufs.page = bufs.addr >> 16;
   bufs.offset = bufs.addr % 65536;
   if (noauto) {
      bufs.length = BLOCK_LENGTH;
   } else {
      bufs.length = BLOCK_LENGTH*2;
   }
/*
 Usual stuff is now set up - try a reset
*/
   printf("Attempting reset of sound card\n");
   if (!resetsb()) {
      printf("sound blaster not resetting\n");
      exit(0);
   }
   printf("Successful\n");
/*
   if (wss) {
      printf(" r%d %x \n",0,inportb(sb.baseio));
      for (i=0;i<16;i++) {
         outportb(sb.baseio,i);
         printf(" %x ",inportb(sb.baseio+1));
         if (i==7) printf("\n");
      }
   }
*/
   if (ptts.enable) {
      printf(" ptt port base address %x \n",ptts.addr);
   }
   if (outaudio.enable) {
      printf(" audio output port base address %x \n",recmic.addr);
   }
   if (recmic.enable) {
      printf(" record mic port base address %x \n",recmic.addr);
   }
   if (recmic.enable && outaudio.enable && recmic.addr == outaudio.addr
      && recmic.mask == outaudio.mask) {
      printf("Error: audio output toggle and mic record toggle are on same line\n");
      exit(1);
   }
   micswitch(0);
   outswitch(0);
   ptt(0);
   done = TRUE;
   sbactive = FALSE;
   play = TRUE;
   recording = FALSE;
   disable();
   setvect(0x60,fake);
   outportb(pic_mask,(inportb(pic_mask)|irqs.stop));
   old_intr_sb = getvect(irqs.vector);
   setvect(irqs.vector,intr_sb);
   outportb(pic_mask,(inportb(pic_mask)&irqs.start));
   enable();
/*
 free environment space before going resident
 to shrink the memory usage a little
*/
   ip = MK_FP(_psp,0x2c);
   freemem(*ip);
   keep(0,program_size());
}
